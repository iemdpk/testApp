from django.apps import AppConfig


class ExecuteConfig(AppConfig):
    name = 'execute'
