from django.shortcuts import render
from django.http import HttpResponse
from selenium import webdriver
import time
from webdriver_manager.chrome import ChromeDriverManager
import json

# Create your views here.

def index(request):
    return render(request,'main.html')


def add(request):
    number = request.GET.get('t1')
    op = webdriver.ChromeOptions()
    op.add_argument('headless')
    driver = webdriver.Chrome(ChromeDriverManager().install())
    

    driver.set_page_load_timeout(50)

    driver.get("https://chatwatch.net/")
    time.sleep(3)
    compNum = '+' + number
    print(compNum)
    driver.find_element_by_id('phone1').send_keys(compNum)
    driver.find_element_by_tag_name("button").click()
    time.sleep(4)
    value = driver.find_element_by_class_name('phone-availability-text').text
    #print("Timing ")
    driver.quit()
    print(value)
    return HttpResponse(json.dumps(value))

